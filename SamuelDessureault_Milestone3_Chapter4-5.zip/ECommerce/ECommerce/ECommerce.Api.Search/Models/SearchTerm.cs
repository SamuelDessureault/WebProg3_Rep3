﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ECommerce.Api.Search.Models
{
    public class SearchTerm
    {
        public int CustomerId { get; set; }
    }
}
